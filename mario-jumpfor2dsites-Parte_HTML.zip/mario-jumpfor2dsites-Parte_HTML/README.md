<h1 align="center">Mario Game 🎮</h1>
   
<h3 align="center">Click here ⤵️</h3>   
<a href="https://projects-gustavo.github.io/mario-jump/"><img src="https://cdn.discordapp.com/attachments/876799799255531523/999749650816970852/mariogame.png"></a>
<div inline:block>
    <img src="https://img.shields.io/badge/html5-%23E34F26.svg?style=for-the-badge&logo=html5&logoColor=white" />
    <img src="https://img.shields.io/badge/css3-%231572B6.svg?style=for-the-badge&logo=css3&logoColor=white" />
    <img src="https://img.shields.io/badge/javascript-%23323330.svg?style=for-the-badge&logo=javascript&logoColor=%23F7DF1E" />
</div>
